
          function checkvalue()
          {
              var oPtUser = document.getElementById('PtUser');
              if(oPtUser.value =="")
              {
                  alert("�����������û�����");
                  oPtUser.focus();
                  return false;
               }
               return true;
          }
          function f_sendLogin() {
			var data;
			$.ajax({
				url: "/portal/logon.cgi",
				type: "POST",
				cache: false,
				async: true,
				dataType: "html",
				data:$("#loginForm").serialize(),
				success: function(json){
					data = json;
					if(json.indexOf("filename=logonSuccess.htm") !== -1)
					{
						window.location.href = "logonSuccess.htm";
						return;
					}
					
					if(json.indexOf("filename=logonFail.htm") !== -1)
					{
						window.location.href = "logonFail.htm";
						return;
					}						

					if(json.indexOf("filename=online.htm") !== -1)
					{
						window.location.href = "online.htm";
						return;
					}		

					if(json.indexOf("filename=Busy.htm") !== -1)
					{
						window.location.href = "Busy.htm";
						return;
					}						
				}
			});
	    }
            function onUserClick(){
                var oPtUser = document.getElementById('PtUser');
                oPtUser.focus();
            }
            function onPwdClick(){
                var oPtPwd = document.getElementById('PtPwd');
                oPtPwd.focus();
            }
            function isDispExtAuthDiv(){
                if(!pt_IsSupportExtAuth())
                {
                    var extauthDiv = document.getElementById("commit-style");
                            extauthDiv.style.display="none";
                }
            }
            function setQQUrl(){		
                if("" == pt_getQQSubmitUrl())
                {
                    alert("����QQ��֤���ã�");
                    return;
                }
		        document.getElementById("qqurl").href = pt_getQQSubmitUrl();
            }             
            function setEmailUrl()
            {              
               if(!pt_IsEmailConfigured())
               {
                    alert("����������֤���ã�");
                    return;
               }
	       
	           document.getElementById("email").href = "emailLogon.htm";
             } 
            function f_Login()
            {
                    var r = checkvalue();
                    if (!r) {
                        return false;
                    }		
                    return f_sendLogin();           	
            }  