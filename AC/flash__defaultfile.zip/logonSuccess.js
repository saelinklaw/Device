					
					function pt_AutoRedirect1() {
						if (szPtJumpUrl == '')
							return;
						try {
							window.location.assign(szPtJumpUrl);
						} catch (e) {
						}
          }

          function pt_init1() {
            setTimeout('pt_AutoRedirect1();', 3000);
						/**
						 * 以下代码调试时使用
						 *  window.resizeTo(400, 500);
						 *  if (navigator.userAgent.indexOf('Chrome') < 0) {
						 *  testWin = window.open('', 'test', 'height=1px,width=1px');
						 *  setTimeout('judge()', 500);
						 *  }
						 * */
          }
					
		      function f_sendLoginoff() {
							var data;
							$.ajax({
								url: "/portal/logon.cgi",
								type: "POST",
								cache: false,
								async: true,
								dataType: "html",
								data:$("#form1").serialize(),
								success: function(json){
							    	data = json;
										if(json.indexOf("filename=logoffSuccess.htm") !== -1)
										{
											window.location.href = "logoffSuccess.htm";
											return;
										}
							  }
							});
					}
					
					 function f_Loginoff()
           {
							  return f_sendLoginoff();	
           	
           } 
           
           